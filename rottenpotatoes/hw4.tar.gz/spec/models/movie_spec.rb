require 'rails_helper'

RSpec.describe Movie, type: :model do
  #Note: This implies that you should write at least 2 specs for your controller: 
  #1) When the specified movie has a director, it should... 
  #2) When the specified movie has no director, it should ... 
  #and 2 for your model:
  #1) it should find movies by the same director and 
  #2) it should not find movies by different directors.
    # describe 'Searching for simillar movies' do
    #     describe 'When all_movies_with_same_director method is called' do
    #       it 'it should find movies by the same director' do
    #       end
    #       it 'it should not find movies by different directorsr' do
    #       end
    #     end
    # end
end
